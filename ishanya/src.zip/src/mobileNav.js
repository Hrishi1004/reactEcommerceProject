import React, { Component } from 'react';
import MenuIcon from '@mui/icons-material/Menu';
import './header.css'

import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';

import logo from './logo.svg'
import './header.css'
import Contact from './contact'
import ProductCard from './Catalog';
import About from './about';
import { BrowserRouter as Router, Link, Route, Switch } from 'react-router-dom';
import Cart from './cart';
import ProductPage from './productPage';
import Home from './home'
import Register from './Register';


export default class MobileNav extends Component {
    state = {
        toggle:false
    }
    Toggle = () => {
        this.setState({toggle:!this.state.toggle})
    }
    render() {
        return (
            <Router>
          <>        
              <div className="navBar">
                    <button onClick={this.Toggle}>
                        <MenuIcon />
                    </button>
                    <ul className={this.state.toggle ? "nav-links show-nav" : "nav-links"}>
                         <li><Button href="/home" color="inherit"> Home</Button></li>
                         <li> <Button href="/Catalog" color="inherit"> Products</Button></li>
                         <li><Button href="/about" color="inherit"> About </Button></li>
                         <li> <Button href="/contact" color="inherit"> Contact </Button></li>
                         <li><Button href="/cart" color="inherit"> Cart </Button></li>
                         <li> <Button href="/Register" color="inherit"> Sign In </Button></li>
                    </ul>
              </div>
           </>
           <Switch>
         <Route path ="/home" component={Home}/>  
          <Route path ="/Catalog" component={ProductCard}/>  
          <Route path ="/about" component={About}/> 
          <Route path ="/contact" component={Contact}/>   
          <Route path ="/cart" component={Cart}/>    
          <Route path ="/productpage" component={ProductPage}/>       
          <Route path ="/Register" component={Register}/>       
         </Switch>
          </Router>
        );
    }
}


