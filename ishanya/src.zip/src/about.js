import { Typography } from '@mui/material';

import * as React from 'react';

export default function About() {
    return (
        <>
        <div style={{maxWidth:700,margin:'50px auto',textAlign:'center'}}>
            <Typography gutterBottom variant="h5">About Ishanya coconut processing </Typography>
             <br/>
            <Typography gutterBottom variant="p">  A Sharp Palette and Striking Colors. This design for Rook keeps things super simple and very sharp by using a strict color palette and clean shapes. Their signature gold shade is used throughout the design in a simple and effective way, by carrying it from the logo, to the imagery, and through to the type.
Hand Crafted Type and Simple Photographs. This About Us page for Madebyband takes a bit of a different approach, but still manages to instantly communicate the brand’s personality via some hand crafted type and a dispersal of simple accompanying images.
Playful Illustrations and Vibrant Palette. A common trope in About Us page designs is to use pho </Typography>
            </div>
        </>
    )
}