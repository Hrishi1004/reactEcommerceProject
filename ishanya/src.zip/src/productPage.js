import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { Button, CardActionArea, CardActions, Grid, TextField } from '@mui/material';
import logo from './logo.svg'
import { typography } from '@mui/system';
import im from './11.png';
import './catalog.css'
import './productPage.css'
import { BrowserRouter as Router, Link, Route, Switch } from 'react-router-dom';
import Cart from './cart';
export default function ProductPage() {
  return (
      <>
      <router>
      <Grid container className="productPageContainer">
          <Grid item  className="productPageImageContainer">
            <img src={im} className="productPageMainImage"/>            
            <Grid item >
              <img src={im}
              style={{padding:5,maxWidth:60,borderRadius:10}}/>
               <img src={im}
               style={{padding:5,maxWidth:60,borderRadius:10}}/>
               <img src={im}
               style={{padding:5,maxWidth:60,borderRadius:10}}/>
               <img src={im}
               style={{padding:5,maxWidth:60,borderRadius:10}}/>
            </Grid>
          </Grid>

             <Grid className="productPageTextContainer">

              <Typography variant="h4" className="productPageTextHeader" >
              Ishanya 100% Pure Coconut Oil, 1 L
               </Typography>
               <br/>
              <Typography variant="body2" style={{fontSize:'18px',paddingBottom:20}}>1 Liter can</Typography>               
                  
              <Typography variant="body2" style={{fontSize:'18px',paddingBottom:20}}>₹ 500 / liter</Typography>    
                <div className="buyButtonMobile">
                  <Button  variant="contained" disableElevation style={{marginBottom:30,}}> Buy</Button> 
                </div>
                <Typography variant="body2" color="text.secondary" style={{overflow:'hidden'}}>
                About this item
                No added preservatives or harsh chemicals
                Unrefined and cold pressed for long lasting freshness
                Ideal for keeping hair smooth and strong
                100% Pure coconut crushing oil
                   <br>
                  </br>
                  <br/>
                  About this item
                  <br/>
                  <br/>
                  No added preservatives or harsh chemicals
                  <br/><br/>
                  Unrefined and cold pressed for long lasting freshness
                  <br/><br/>
                  Ideal for keeping hair smooth and strong
                  <br/><br/>
                  100% Pure coconut crushing oil
                 </Typography>
             <br/>
            <div  className="buyButton">
              <Button href="/cart" variant="contained" disableElevation style={{marginBottom:30,}}> Buy</Button>    
            </div>                       
        </Grid>     
      </Grid> 

  <div  className="productContainer">      
    <div className="productWrap">   
    <Card  className="productCard" >
       <CardActionArea>
        <CardMedia
          component="img"
          height="170"
          image={logo}
        />
        <CardContent style={{paddingTop:5,textAlign:'left'}}>
          <Typography gutterBottom variant="body2" component="div" style={{fontWeight:530,height:40,overflow:'hidden'}}>
         Ishanya 100% Pure Coconut Oil, 1 L
          </Typography>

          <Typography variant="body2" color="text.secondary" style={{height:40,textAlign:'left',overflow:'hidden'}}>
          No added preservatives or harsh chemicals
                Unrefined and cold pressed for long lasting freshness
                Ideal for keeping hair smooth and strong
                100% Pure coconut crushing oil
          </Typography>
        <CardActions style={{padding:'10px 0 0 0 ' ,display:"flex",justifyContent:'space-between'}}>
        <Typography variant="body2" color="text.secondary" >
          ₹ 500 / liter
        </Typography>
        <Button variant="contained" size="small" disableElevation> Buy </Button>
       </CardActions>
        </CardContent>
      </CardActionArea>
    </Card>

    <Card  className="productCard" >
       <CardActionArea>
        <CardMedia
          component="img"
          height="170"
          image={logo}
        />
        <CardContent style={{paddingTop:5,textAlign:'left'}}>
          <Typography gutterBottom variant="body2" component="div" style={{fontWeight:530,height:40,overflow:'hidden'}}>
         Ishanya 100% Pure Coconut Oil, 1 L
          </Typography>
          <Typography variant="body2" color="text.secondary" style={{height:40,textAlign:'left',overflow:'hidden'}}>
          No added preservatives or harsh chemicals
                Unrefined and cold pressed for long lasting freshness
                Ideal for keeping hair smooth and strong
                100% Pure coconut crushing oil
          </Typography>
        <CardActions style={{padding:'10px 0 0 0 ' ,display:"flex",justifyContent:'space-between'}}>
        <Typography variant="body2" color="text.secondary" >
          ₹ 500 / liter
        </Typography>
        <Button variant="contained" size="small" disableElevation> Buy </Button>
       </CardActions>
        </CardContent>
      </CardActionArea>
    </Card>


    <Card  className="productCard" >
       <CardActionArea>
        <CardMedia
          component="img"
          height="170"
          image={logo}
        />
        <CardContent style={{paddingTop:5,textAlign:'left'}}>
          <Typography gutterBottom variant="body2" component="div" style={{fontWeight:530,height:40,overflow:'hidden'}}>
         Ishanya 100% Pure Coconut Oil, 1 L
          </Typography>
          <Typography variant="body2" color="text.secondary" style={{height:40,textAlign:'left',overflow:'hidden'}}>
          No added preservatives or harsh chemicals
                Unrefined and cold pressed for long lasting freshness
                Ideal for keeping hair smooth and strong
                100% Pure coconut crushing oil
          </Typography>
        <CardActions style={{padding:'10px 0 0 0 ' ,display:"flex",justifyContent:'space-between'}}>
        <Typography variant="body2" color="text.secondary" >
          ₹ 500 / liter
        </Typography>
        <Button variant="contained" size="small" disableElevation> Buy </Button>
       </CardActions>
        </CardContent>
      </CardActionArea>
    </Card>

    
    <Card  className="productCard" >
       <CardActionArea>
        <CardMedia
          component="img"
          height="170"
          image={logo}
        />
        <CardContent style={{paddingTop:5,textAlign:'left'}}>
          <Typography gutterBottom variant="body2" component="div" style={{fontWeight:530,height:40,overflow:'hidden'}}>
         Ishanya 100% Pure Coconut Oil, 1 L
          </Typography>
          <Typography variant="body2" color="text.secondary" style={{height:40,textAlign:'left',overflow:'hidden'}}>
          No added preservatives or harsh chemicals
                Unrefined and cold pressed for long lasting freshness
                Ideal for keeping hair smooth and strong
                100% Pure coconut crushing oil
          </Typography>
        <CardActions style={{padding:'10px 0 0 0 ' ,display:"flex",justifyContent:'space-between'}}>
        <Typography variant="body2" color="text.secondary" >
          ₹ 500 / liter
        </Typography>
        <Button variant="contained" size="small" disableElevation> Buy </Button>
       </CardActions>
        </CardContent>
      </CardActionArea>
    </Card>

    
    <Card  className="productCard" >
       <CardActionArea>
        <CardMedia
          component="img"
          height="170"
          image={logo}
        />
        <CardContent style={{paddingTop:5,textAlign:'left'}}>
          <Typography gutterBottom variant="body2" component="div" style={{fontWeight:530,height:40,overflow:'hidden'}}>
         Ishanya 100% Pure Coconut Oil, 1 L
          </Typography>
          <Typography variant="body2" color="text.secondary" style={{height:40,textAlign:'left',overflow:'hidden'}}>
          No added preservatives or harsh chemicals
                Unrefined and cold pressed for long lasting freshness
                Ideal for keeping hair smooth and strong
                100% Pure coconut crushing oil
          </Typography>
        <CardActions style={{padding:'10px 0 0 0 ' ,display:"flex",justifyContent:'space-between'}}>
        <Typography variant="body2" color="text.secondary" >
          ₹ 500 / liter
        </Typography>
        <Button variant="contained" size="small" disableElevation> Buy </Button>
       </CardActions>
        </CardContent>
      </CardActionArea>
    </Card>

    <Card  className="productCard" >
       <CardActionArea>
        <CardMedia
          component="img"
          height="170"
          image={logo}
        />
        <CardContent style={{paddingTop:5,textAlign:'left'}}>
          <Typography gutterBottom variant="body2" component="div" style={{fontWeight:530,height:40,overflow:'hidden'}}>
         Ishanya 100% Pure Coconut Oil, 1 L
          </Typography>
          <Typography variant="body2" color="text.secondary" style={{height:40,textAlign:'left',overflow:'hidden'}}>
          No added preservatives or harsh chemicals
                Unrefined and cold pressed for long lasting freshness
                Ideal for keeping hair smooth and strong
                100% Pure coconut crushing oil
          </Typography>
        <CardActions style={{padding:'10px 0 0 0 ' ,display:"flex",justifyContent:'space-between'}}>
        <Typography variant="body2" color="text.secondary" >
          ₹ 500 / liter
        </Typography>
        <Button variant="contained" size="small" disableElevation> Buy </Button>
       </CardActions>
        </CardContent>
      </CardActionArea>
    </Card>

    
    </div>
    </div>
    
    <Switch>
          
          <Route path ="/cart" component={Cart}/>    
    </Switch>
    </router>
      </>
  );
}