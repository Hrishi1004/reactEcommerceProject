import logo from './logo.svg';
import './App.css';
import Appbar from './header'
import ProductCard from './Catalog'
import ProductPage from './productPage';
import Home from './home';
import Cart from './cart'
import Register from './Register'
import Addres from './Address';
import Login from './Login';
import ForgotPassword from './forgotPassword';
import About from './about';
import Contact from './contact'
import MobileNav from './mobileNav';

function App() {
  return (
    <div className="App">    
     <Appbar/>
   
    </div>
  );
}
export default App;
